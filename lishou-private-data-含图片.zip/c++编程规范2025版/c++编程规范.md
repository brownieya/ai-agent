# C++编程规范

###### 隶首公司2025版

## 1.命名

所有的命名，都希望能望文知意，能够看到名字就大致能理解是干什么的，无论是变量、函数还是宏，都需要做到直观，这是基本的原则。

### 1.1.变量命名

现使用的命名规则为“匈牙利命名法”，匈牙利命名法是早期计算机程序设计中的一种命名规则，匈牙利命名主要包括三个部分:基本类型、一个或更多的前缀、一个限定词。用这种方法命名的变量优势是显示了其数据类型。这种命名法最初在20世纪80年代的微软公司广泛使用，并在win32API和MFC库中广泛的使用，但也有较多争议。
建议如下：
A、对已有项目工程，沿用原工程的命名方法。
B、对于新工程，为了适用我们原有的底层库，建议使用匈牙利命名法。

局部变量，如果需要多词组合，如：nMaxLength,
Linux或其他开发环境以下划线分割并都小写也可，如max_length。
成员变量，如果需要多词组合，建议每个词的首字母都大写，如：int* m_pMaxNumber，成员变量建议按照匈牙利命名法，用m_开头。
静态变量，建议加前缀s_
全局变量，要求用g_开头。

### 1.2.类与函数命名

类名和函数名建议用大写字母开头的单词组合而成，如：
class CConSysDoc{
bool LoadResultFromFile(LPCTSTR file);
}

### 1.3.变量类型选择

非必要
不用float, 直接使用double；
double变量名前缀建议用fValue, 不用dValue;
不用BYTE做返回值等目标是解决字节数的行为，直接用int；
BYTE对应变量名前缀不用bRet, 把它看成整数 iRet或nRet更合理

## 2.代码风格

### 2.1.排版

程序块采用缩进风格编写，每级缩进为4个空格，现VS2019/2022自动支持缩进。
宏定义、编译开关、条件预处理语句可以顶格，无需缩进。

### 2.2.代码行

一行代码必须只做一件事，如：一条语句，定义一个变量。
if、for、while、do 必须是独立的一行。
“{}”使用时，建议沿用新工程风格，新工程建议“{”与在前一个相关语句同行。如：
Class CNode {
}
for (int i=0; i<100; i++) {
}
当一行代码过长时，建议分行显示。

### 2.3.程序块

同一个函数内的相对独立的程序块之间，建议增加空行。如果独立的程序块行数较多，建议抽取出来作为独立的函数。

### 2.4.类的声明

类的声明要求将public相关的接口与属性放在前面，private相关的接口与属性放在后面。同时，相同权限修饰符的接口与属性需要分在两个修饰符下，如若相同的权限修饰符下的接口或者属性因功能、类型等成独立规模时，建议放在独立的权限修饰符下。如：

public: // vtk相关
vtkMFCWindow* m_pMfcWindow;
vtkSmartPointer m_pRen;
vtkSmartPointer m_pRenWin;
vtkSmartPointer m_pRenInteractor;
vtkSmartPointer m_pCamOriWidget;

public:
bool m_bIsHand = false;//记录鼠标样式
bool m_bIsSelectNode = true;
bool m_bIsSelectElement = true;

## 3.常量、宏

### 3.1.常量使用const定义代替宏

### 3.2.使用函数代替功能块宏

### 3.3.使用宏时，要使用完备的括号，如:

\#define RECTANGLE AREA(a, b) ((a)*(b))

### 3.4.MFC资源准从微软标识符风格

字符串：IDS_****
对话框：IDD_DLG_XXX
控件：IDC_EDIT_***, IDC_COMBO_***, IDC_CHECK_***, IDC_BTN_***，……
位图:IDB_***
……

## 4.指针、内存

指针的使用与内存的管理一直是c++的难点，使用不当，轻则导致内存泄漏，重则导致程序的崩溃，故需慎重对待！~

### 4.1.指针变量命名

要p/ptr开头，pNextNode, m_ptrBuf;
指针分配时要对负责释放指针的机制有预见，必须心中有数；
注意调用其他函数返回的指针，要了解是否有释放责任；

### 4.2.尽量使用智能指针

C++标准库提供了几种智能指针类型，包括std::unique_ptr、std::shared_ptr、std::weak_ptr；基本够用了。

### 4.3.智能指针与裸指针不建议混用

如下混用可能会引入其他问题：
CNode* pNodeTemp = new CNode();
std::shared_ptr ptrNode(pNodeTemp);
pNodeTemp->....

### 4.4.申请内存须对内存释放有一个明确的预期，特别是裸指针。

### 4.5.裸指针需付初始值，如nullptr。

### 4.6.申请使用资源，如GDI资源、线程资源等，需明确资源的释放。

### 4.7.模块内申请的内存、资源等，模块需提供对外的释放接口。

### 4.8.指针使用，保持判断为空的好习惯。

我们常有这样的代码：
CConSysDoc* pdoc = (CConSysDoc*)(GetDocument());
CDocData* pData = pdoc->GetDocData();
pData->.....
以上代码，建议添加指针使用的判断:
CConSysDoc* pdoc = (CConSysDoc*)(GetDocument());
if (pdoc == nullptr) {
return;
}
CDocData* pData = pdoc->GetDocData();
if (pData == nullptr){
return;
}
pData->.....
添加指针为空的判断处理，虽然代码啰嗦点，但这样程序能够更加健壮，能够处理意外情况，而且，在调试代码时，更容易定位问题。

## 5.头文件

C++头文件使用不当，会引起互相引用。

### 5.1.头文件保护

.h文件，必须要有#pragma once 或 #ifndef __H 保护，虽然#ifndef更便于移植，但为了简单起见，建议使用#pragma once。

### 5.2.头文件内部，减少不必要的#include

例如，我们很多地方会用到CConSysDoc指针，但我们头文件内部不需要包含ConSysDoc.h，可在.cpp文件内部包含ConSysDoc.h，至于头文件内部，可以直接使用前置声明class CConSysDoc即可。

### 5.3.注意#include “filename.h”与#include <filename.h>的区别

用 #include <filename.h> 格式来引用标准库的头文件（编译器将从标准库目录开始搜索）。
用 #include “filename.h” 格式来引用非标准库的头文件（编译器将从用户的工作目录开始搜索）。

## 6.想一下

### 6.1.尽量避免造轮子

你遇到的需求其他人大概率也遇到过，ASK! 避免重复研究轮子。公司开发环境中yblib内有大量常用函数，推荐的几个方面：

- Path::名字空间的文件路径合成、文件路径处理函数
- CAutoBuffer比自己char szBuf[nSize]好用很多
- Json类目前大量使用
- Unicode，utf8编码转换函数
- 消息队列机制支持线程池很方便
- 同步对象
- Tcp，http通信类

### 6.2.代码复用

如果你发现自己copy了/或需要copy一大段代码，只要稍微改几个地方的情況，那么最好还是提取一个公共函数。
有时候拉姆达函数是一个简单的方案，请学习之。