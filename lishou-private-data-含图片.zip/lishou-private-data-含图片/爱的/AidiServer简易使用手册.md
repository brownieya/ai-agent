AidiServer是用于提供爱的ERP数据库与MYMES系统数据同步的服务，内部提供了数据库连接、数据库查询、网络连接与查询等功能。对外提供post 与 get两种接口。

###### 1、配置：

在aidiserver.exe同路径下添加setting.ini,需配置网络、sqlserver服务器、日志三个部分。示例如下：

网络配置：

[net]

ip=192.168.2.4

port=8088

 

sqlserver服务器配置：

[sqlserver]

// 服务器及端口配置

server=192.168.2.201,12332  

// 数据库配置

database=dbeis_bes-cs  

// 用户名

uid=sa  

// 用户密码

pwd=lsSqlServer

 

日志配置，可根据需要配置日志路径，不配置默认生成在AidiServer.exe所在的路径下的logs子路径

[log]

path=C:\Muye\AidiSql\logs

 

###### 2、服务相关

首次使用，需要配置服务，在系统中配置服务，假设AidiServer.exe被拷贝到C:\Muye\AidiSql\路径下，需要用到的命令如下：

创建服务：

sc create AidiService binPath= "C:\Muye\AidiSql\AidiServer.exe" start= auto

启动服务...

net start AidiService

停止服务...

net stop AidiService

删除服务...

sc delete AidiService

 

###### 3、接口调用

查询接口：

http://ip:port/getOrder/order

http://ip:port/postOrder/order

接口支持GET与POST，分别对应getOrder与postOrder，order为具体的命令，现支持的命令如下：

| order         | 功能                                           |
| ------------- | ---------------------------------------------- |
| querySales    | 查询订单，获取订单的json数据                   |
| queryFeedback | 对上次查询结果的确认，用于确定最后成功查询时间 |
|               |                                                |

order 功能

querySales 查询订单，获取订单的json数据

queryFeedback 对上次查询结果的确认，用于确定最后成功查询时间

 

 

其中ip 与port就是setting.ini里面的配置的[net]下的ip与port,如以上配置，查询接口Get可以是：

http://192.168.2.4:8088/getOrder/querySales

接口参数详情请参见文档：

https://share.note.youdao.com/s/PC2v8wfE

 

###### 4、日志查询

日志在配置文件setting.ini中[log]path参数所配置的路径中(默认生成在AidiServer.exe所在的路径下的logs子路径)，文件名为aidiserver.log,最多可以有5个日志文件，多余的会删除，每次启动会重新创建一个新文件。日志截图如下：

![img](assets/server-log.png)

每行日志格式分别对应：

[时间] [线程ID] [信息类型] 日志内容