# MES仓库相关

简单整理，aidi仓库和生产过程的配合，包含手动和自动流程需要的界面和逻辑开发。

## 物料库存管理

### 1. 数据结构

```sql
-- 库存表
CREATE TABLE inventory (
    id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '主键',
    warehouse INT(11) NOT NULL COMMENT '所在仓库',
    mutplebin VARCHAR(50) COMMENT '所在库位',
    sequence INT NOT NULL DEFAULT 0 COMMENT '顺序',
    foam INT(11) NOT NULL COMMENT '材质类型',
    inType TINYINT(1) UNSIGNED NOT NULL DEFAULT 1 COMMENT '入库类型：1 发泡入库，2-返库',
    SERIAL VARCHAR(50) NOT NULL COMMENT '序列号',
    originserial VARCHAR(50) NOT NULL COMMENT '来源序列号',
    ispint ENUM( 'true' , 'false') DEFAULT 'false' COMMENT '状态 false-未排料,true-已排料;',
    isremnant ENUM( 'true' , 'false') DEFAULT 'false' COMMENT '状态 false-正常料,true-余料;',
    hasskin ENUM( 'true' , 'false') DEFAULT 'false' COMMENT '是否有底皮',
    LENGTH DOUBLE DEFAULT 0  COMMENT '物料-当前长度',
    width DOUBLE DEFAULT 0 COMMENT '物料-当前宽度',
    height DOUBLE DEFAULT 0 COMMENT '物料-当前高度',
    weight DOUBLE DEFAULT 0 COMMENT '物料-当前重量',
    COMMENT VARCHAR(256) COMMENT '备注',
    isactive ENUM( 'true' , 'false') DEFAULT 'true' COMMENT '状态 true-可用,false-禁用;',
    inv_type TINYINT(1) UNSIGNED NOT NULL DEFAULT 0 COMMENT '库存类型: 0-实际库存, 1-计划库存,默认 0-实际库存',
    isMultiDPint ENUM( 'true' , 'false') DEFAULT 'false' COMMENT '用于多厚度排料',
    createddate DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updateddate DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    foamingdate DATETIME NULL COMMENT '发泡日期',
    PRIMARY KEY (id)
) ENGINE=INNODB CHARSET=utf8mb4;
-- 库存操作日志表
CREATE TABLE inventory_log (
    id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '主键',
    inventory INT(11) NOT NULL COMMENT '库存信息',
    TYPE INT(11) NOT NULL COMMENT '操作类型 1-入库；2-出库；3-移库；4-返库',
    LENGTH DOUBLE DEFAULT 0 COMMENT '物料-操作长度',
    width DOUBLE DEFAULT 0 COMMENT '物料-操作宽度',
    height DOUBLE DEFAULT 0 COMMENT '物料-操作高度',
    weight DOUBLE DEFAULT 0 COMMENT '物料-操作重量',
    userid INT(11) NOT NULL COMMENT '操作人员',
    COMMENT VARCHAR(256) COMMENT '备注',
    transdate DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    PRIMARY KEY (id)
) ENGINE=INNODB CHARSET=utf8mb4;
```

- 数据库中使用`inventory`表管理物料库存，`inventory_log`表管理物料库存操作记录，其他关联表为`blklib_foamtype`材质类型关联表，`warehouse`仓库表。
- 除了基础的材质，长宽高以外，一些字段是排料需要：isMultiDPint、ispint，其他字段是加工生产需要的

### 2. 网站仓库界面

- 网站提供了库存列表，仓库列表，海绵材质列表的操作界面和库存操作记录列表的查看界面

### 3. api接口

网站提供了对物料库存的出入库相关接口，详细说明和样例可以查看**牧野-数据中心API手册.xlsx**

- 入库/批量接口：发送单个入库库存或入库库存列表，返回对应顺序的库存ID和库存序列号，入库失败时对应的库存ID小于0；由于一个仓位会存放多个库存海绵，所以库存表增加了sequence表示这个仓位内库存的顺序，单个入库时也可以选择正向入库或反向入库，并且带上插入的前一个库存id号，自动将同仓位的所有库存进行重新排序。
- 返库接口：发送带序列号的库存呢
- 出库/批量出库接口：发送单个库存ID或库存ID列表，出库失败时返回出库失败的库存ID，成功不返回data数据。
- 更新接口：发送带单个库存ID的库存更新信息，根据库存ID匹配相关库存并更新，根据返回code==0判断是否返回成功。
- 库存查询接口：发送查询条件，根据条件返回库存信息列表。
- 材质类型查询接口：发送查询条件，根据条件返回材质类型列表。
- 材质类型新增/批量新增接口：发送单个材质类型/材质类型列表，返回对应顺序的材质类型编码列表，成功时材质编码对应系统ID大于0，失败时对应系统ID小于0。

### 4. MES使用物料库存相关逻辑

- 排料阶段：可以选择现有的物料库存进行排料（短泡和长泡），产生的排料结果也就时加工任务会直接关联使用的库存ID;进行断泡规划时会产生长泡和短泡的计划库存（inv_type=1）。
- 加工阶段：查看排产任务列表时会同时显示关联的库存信息，在自动流程中，备料时发送到WCS的备料请求会带上相关的库存ID和材质长宽高等信息，由WCS判断应该使用哪个海绵并送料。若是存在退料请求，会发送剩余的海绵信息到WCS进行退库或重新入库。
- aidi特殊的通道库+震动刀备料加工逻辑可以查看**整切任务加工流程设计文档**

## 零件库存管理

### 1. 数据结构

```sql
-- 零件库存表
DROP TABLE IF EXISTS `inventory_blk`;
CREATE TABLE `inventory_blk` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '主键',
  `serial` VARCHAR(50) NOT NULL COMMENT '序列号',
  `originserial` VARCHAR(50) NULL COMMENT '来源序列号'
  `warehouse` INT(11) UNSIGNED DEFAULT NULL COMMENT '所在仓库',
  `mutplebin` VARCHAR(50) DEFAULT NULL COMMENT '所在库位',
  `sequence` INT NOT NULL DEFAULT 0 COMMENT '顺序',
  `blkid` INT(11) UNSIGNED NOT NULL COMMENT '关联的零件ID',
  `quantity` INT(11) UNSIGNED DEFAULT NULL COMMENT '总库存数量',
  `realX` DOUBLE DEFAULT '0' COMMENT '零件为卷绵时，每卷的实际长度',
  `taskid` INT(11) UNSIGNED DEFAULT NULL COMMENT '可填，关联的任务id',
  `locked_quantity` INT(11) UNSIGNED DEFAULT NULL COMMENT '已锁定库存数量（已分配给订单，未出库）',
  `createddate` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updateddate` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `comment` VARCHAR(100) DEFAULT NULL COMMENT '备注',
  `isactive` ENUM( 'true' , 'false') DEFAULT 'true' COMMENT '状态 true-可用,false-禁用;',
  PRIMARY KEY (`id`)
) ENGINE=INNODB DEFAULT CHARSET=utf8mb4;


-- 零件库存订单表
DROP TABLE IF EXISTS `inv_blk_order`;
CREATE TABLE `inv_blk_order` (
  `id` INT(11) UNSIGNED NOT NULL COMMENT '关联表主键',
  `invid` INT(11) UNSIGNED NOT NULL COMMENT '库存id',
  `orderid` INT(11) UNSIGNED NOT NULL COMMENT '订单id',
  `quantity` INT(11) DEFAULT NULL COMMENT '库存中属于此订单的数量',
  `quantity_out` INT(11) DEFAULT NULL COMMENT '已出库数量',
  `createddate` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updateddate` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `realX` DOUBLE DEFAULT '0' COMMENT '针对卷绵的库存，每卷的实际长度',
  PRIMARY KEY (`id`)
) ENGINE=INNODB DEFAULT CHARSET=utf8mb4;

-- 零件库存操作记录
DROP TABLE IF EXISTS `inv_blk_log`;
CREATE TABLE `inv_blk_log` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '主键',
  `invid` INT(11) UNSIGNED NOT NULL COMMENT '零件库存id',
  `type` TINYINT(1) NOT NULL COMMENT '操作类型，0-入库，1-出库',
  `blkid` INT(11) NOT NULL COMMENT '库存零件id',
  `quantity` INT(11) NOT NULL COMMENT '操作库存数量',
  `userid` INT(11) NOT NULL COMMENT '操作用户',
  `transdate` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '操作时间',
  `realX` DOUBLE DEFAULT '0' COMMENT '针对卷绵的库存，每卷的实际长度',
  PRIMARY KEY (`id`)
) ENGINE=INNODB DEFAULT CHARSET=utf8mb4;
```

- 目前仅设计了排料需要的一些字段，根据仓库WCS需要可能需要新增一些字段或表
- 库存零件表：主要关联零件id+总库存数量，对于特殊的卷绵零件，需要额外增加卷绵实际长度来记录；可关联任务id表示零件的产生来源任务；已锁定库存数量，这个字段仅在零件规划时使用，保证零件库存不会被重复规划，实际出库时需要对这个字段判断区分出库类型。
- 零件库存订单表：此表属于记录表，记录零件规划后订单和零件库存的关系，以及关联库存是否已经进行分拣出库
- 零件库存操作记录表：按时间记录零件库存的入库/出库操作。

### 2.界面

提供了零件库存的查看、入库、出库和编辑功能
提供了零件库存操作记录的查看功能
待提供零件规划界面

### 3.api接口

仅设计，待开发；由于零件和物料库存有可能会放在同一个仓库甚至同一个仓位里面，所以新设计的这一套api接口是需要同时操作零件库存和物料库存的，并且实际WCS实际使用时，按厂家需求分别使用两套（出库/入库）api,不能混用。

- 查询库存：
- 批量入库/更新
- 批量出库